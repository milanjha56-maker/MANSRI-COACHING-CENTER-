# ManSri Coaching Center — Online Portal

Full-stack Node.js + Express + PostgreSQL application for ManSri Coaching Center.

## Included
- Secure server-side admin/student authentication
- Admin: students, credentials, photos, exams, MCQ questions, publish/unpublish, results, fees/payments, center settings
- Student: own profile, published CBT exams, timer, automatic scoring, own results and payment history
- Correct answers are never sent to the student browser; scoring happens on the server
- PostgreSQL database for multi-device persistence

## Render deployment
1. Create a Render PostgreSQL database and copy its internal/external connection string into `DATABASE_URL`.
2. Create a Render Web Service from this repository.
3. Build Command: `npm install`
4. Start Command: `npm start`
5. Set environment variables:
   - `DATABASE_URL` = your Render PostgreSQL connection string
   - `SESSION_SECRET` = a long random secret
   - `ADMIN_USERNAME` = `Milan Jha`
   - `ADMIN_PASSWORD` = `Milan@56`
   - `NODE_ENV` = `production`
6. The app listens on `0.0.0.0` and `PORT` supplied by Render.

Do not commit `.env` files or passwords to GitHub.
