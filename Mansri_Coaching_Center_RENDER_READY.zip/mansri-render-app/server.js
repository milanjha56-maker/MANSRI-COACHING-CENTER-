const express = require('express');
const path = require('path');
const bcrypt = require('bcryptjs');
const cookieSession = require('cookie-session');
const multer = require('multer');
const { Pool } = require('pg');

const app = express();
const PORT = Number(process.env.PORT || 10000);
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL ? { rejectUnauthorized: false } : false });

app.use(express.json({ limit: '6mb' }));
app.use(express.urlencoded({ extended: true, limit: '6mb' }));
app.use(cookieSession({
  name: 'mansri_session',
  keys: [process.env.SESSION_SECRET || 'change-this-secret-before-production'],
  httpOnly: true,
  sameSite: 'lax',
  secure: process.env.NODE_ENV === 'production',
  maxAge: 1000 * 60 * 60 * 12
}));

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 1024 * 1024 },
  fileFilter: (_, file, cb) => /^image\/(jpeg|png|webp)$/.test(file.mimetype) ? cb(null, true) : cb(new Error('Only JPG, PNG or WEBP images are allowed'))
});

async function db(q, params=[]) { return pool.query(q, params); }

async function initDb() {
  if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is not configured');
  await db(`
    CREATE TABLE IF NOT EXISTS admins (
      id SERIAL PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS students (
      id SERIAL PRIMARY KEY, user_id TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, name TEXT NOT NULL,
      guardian TEXT DEFAULT '', phone TEXT DEFAULT '', batch TEXT DEFAULT '', fees NUMERIC(12,2) DEFAULT 0,
      admission_date TEXT DEFAULT '', address TEXT DEFAULT '', photo TEXT DEFAULT '', active BOOLEAN NOT NULL DEFAULT TRUE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS exams (
      id SERIAL PRIMARY KEY, title TEXT NOT NULL, subject TEXT DEFAULT '', duration INTEGER NOT NULL DEFAULT 30,
      published BOOLEAN NOT NULL DEFAULT FALSE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS questions (
      id SERIAL PRIMARY KEY, exam_id INTEGER NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
      question TEXT NOT NULL, option_a TEXT NOT NULL, option_b TEXT NOT NULL, option_c TEXT NOT NULL,
      option_d TEXT NOT NULL, correct CHAR(1) NOT NULL CHECK(correct IN ('A','B','C','D'))
    );
    CREATE TABLE IF NOT EXISTS attempts (
      id SERIAL PRIMARY KEY, exam_id INTEGER NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
      student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE, score INTEGER NOT NULL,
      total INTEGER NOT NULL, answers_json JSONB NOT NULL DEFAULT '{}'::jsonb,
      started_at TIMESTAMPTZ, submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE(exam_id, student_id)
    );
    CREATE TABLE IF NOT EXISTS payments (
      id SERIAL PRIMARY KEY, student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
      amount NUMERIC(12,2) NOT NULL, paid_on TEXT NOT NULL, note TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
  `);
  const username = process.env.ADMIN_USERNAME || 'Milan Jha';
  const password = process.env.ADMIN_PASSWORD || 'Milan@56';
  const exists = await db('SELECT id FROM admins WHERE username=$1', [username]);
  if (!exists.rowCount) {
    await db('INSERT INTO admins(username,password_hash) VALUES($1,$2)', [username, bcrypt.hashSync(password, 12)]);
  }
  await db(`INSERT INTO settings(key,value) VALUES('center_name','ManSri Coaching Center') ON CONFLICT(key) DO NOTHING`);
}

function adminOnly(req,res,next){ if(req.session?.user?.role !== 'admin') return res.status(403).json({error:'Admin only'}); next(); }
function studentOnly(req,res,next){ if(req.session?.user?.role !== 'student') return res.status(403).json({error:'Student only'}); next(); }
function auth(req,res,next){ if(!req.session?.user) return res.status(401).json({error:'Login required'}); next(); }
function studentRow(r){ if(!r) return r; const x={...r}; delete x.password_hash; return x; }

app.post('/api/login', async (req,res,next)=>{
  try {
    const {username,password,role} = req.body;
    if(!username || !password) return res.status(400).json({error:'Username and password are required'});
    if(role === 'admin') {
      const r=await db('SELECT * FROM admins WHERE LOWER(username)=LOWER($1) LIMIT 1',[username.trim()]);
      if(!r.rowCount || !bcrypt.compareSync(password,r.rows[0].password_hash)) return res.status(401).json({error:'Invalid admin login'});
      req.session.user={role:'admin',id:r.rows[0].id,username:r.rows[0].username};
    } else {
      const r=await db('SELECT * FROM students WHERE user_id=$1 LIMIT 1',[username.trim()]);
      if(!r.rowCount || !r.rows[0].active || !bcrypt.compareSync(password,r.rows[0].password_hash)) return res.status(401).json({error:'Invalid student login'});
      req.session.user={role:'student',id:r.rows[0].id,user_id:r.rows[0].user_id,name:r.rows[0].name};
    }
    res.json({ok:true,user:req.session.user});
  } catch(e){next(e)}
});
app.post('/api/logout',(req,res)=>{req.session=null;res.json({ok:true})});
app.get('/api/me',(req,res)=>res.json({user:req.session?.user||null}));

app.get('/api/student/me', studentOnly, async (req,res,next)=>{try{
  const s=(await db(`SELECT id,user_id,name,guardian,phone,batch,fees,admission_date,address,photo,active,created_at FROM students WHERE id=$1`,[req.session.user.id])).rows[0];
  const payments=(await db(`SELECT id,amount,paid_on,note FROM payments WHERE student_id=$1 ORDER BY paid_on DESC,id DESC`,[s.id])).rows;
  const results=(await db(`SELECT a.id,a.score,a.total,a.submitted_at,e.title,e.subject FROM attempts a JOIN exams e ON e.id=a.exam_id WHERE a.student_id=$1 ORDER BY a.submitted_at DESC`,[s.id])).rows;
  res.json({student:s,payments,results});
}catch(e){next(e)}});

app.get('/api/exams/published', studentOnly, async (req,res,next)=>{try{
  const rows=(await db('SELECT id,title,subject,duration FROM exams WHERE published=TRUE ORDER BY id DESC')).rows;
  const attempted=new Set((await db('SELECT exam_id FROM attempts WHERE student_id=$1',[req.session.user.id])).rows.map(x=>x.exam_id));
  res.json(rows.map(x=>({...x,attempted:attempted.has(x.id)})));
}catch(e){next(e)}});

app.get('/api/exams/:id', auth, async (req,res,next)=>{try{
  const e=(await db('SELECT id,title,subject,duration,published FROM exams WHERE id=$1',[req.params.id])).rows[0];
  if(!e) return res.status(404).json({error:'Exam not found'});
  if(req.session.user.role==='student' && !e.published) return res.status(403).json({error:'Exam not published'});
  const qs=(await db('SELECT id,question,option_a,option_b,option_c,option_d FROM questions WHERE exam_id=$1 ORDER BY id',[e.id])).rows;
  res.json({...e,questions:qs});
}catch(e){next(e)}});

app.post('/api/exams/:id/start', studentOnly, async (req,res,next)=>{try{
  const e=(await db('SELECT id,duration,published FROM exams WHERE id=$1',[req.params.id])).rows[0];
  if(!e || !e.published) return res.status(404).json({error:'Exam unavailable'});
  const old=await db('SELECT id,started_at,submitted_at FROM attempts WHERE exam_id=$1 AND student_id=$2',[e.id,req.session.user.id]);
  if(old.rowCount) return res.status(409).json({error:'You have already attempted this exam'});
  res.json({ok:true,started_at:new Date().toISOString(),duration:e.duration});
}catch(e){next(e)}});

app.post('/api/exams/:id/submit', studentOnly, async (req,res,next)=>{try{
  const e=(await db('SELECT * FROM exams WHERE id=$1 AND published=TRUE',[req.params.id])).rows[0];
  if(!e) return res.status(404).json({error:'Exam unavailable'});
  const client=await pool.connect();
  try {
    await client.query('BEGIN');
    const lock=await client.query('SELECT id FROM attempts WHERE exam_id=$1 AND student_id=$2 FOR UPDATE',[e.id,req.session.user.id]);
    if(lock.rowCount) { await client.query('ROLLBACK'); return res.status(409).json({error:'You have already attempted this exam'}); }
    const qs=(await client.query('SELECT id,correct FROM questions WHERE exam_id=$1 ORDER BY id',[e.id])).rows;
    const answers=req.body.answers||{}; let score=0;
    for(const q of qs) if(answers[q.id]===q.correct) score++;
    await client.query(`INSERT INTO attempts(exam_id,student_id,score,total,answers_json) VALUES($1,$2,$3,$4,$5)`,[e.id,req.session.user.id,score,qs.length,JSON.stringify(answers)]);
    await client.query('COMMIT');
    res.json({ok:true,score,total:qs.length});
  } catch(err){ await client.query('ROLLBACK'); throw err; } finally {client.release();}
}catch(e){next(e)}});

app.get('/api/admin/students',adminOnly,async(req,res,next)=>{try{res.json((await db(`SELECT id,user_id,name,guardian,phone,batch,fees,admission_date,address,photo,active,created_at FROM students ORDER BY id DESC`)).rows)}catch(e){next(e)}});
app.post('/api/admin/students',adminOnly,upload.single('photo'),async(req,res,next)=>{try{
  const b=req.body;if(!b.user_id||!b.password||!b.name)return res.status(400).json({error:'User ID, password and name are required'});
  const photo=req.file?`data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`:'';
  const r=await db(`INSERT INTO students(user_id,password_hash,name,guardian,phone,batch,fees,admission_date,address,photo,active) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,[b.user_id.trim(),bcrypt.hashSync(b.password,12),b.name,b.guardian||'',b.phone||'',b.batch||'',Number(b.fees||0),b.admission_date||'',b.address||'',photo,b.active!=='0']);
  res.json({ok:true,id:r.rows[0].id});
}catch(e){res.status(400).json({error:e.code==='23505'?'Student User ID already exists':e.message})}});
app.put('/api/admin/students/:id',adminOnly,upload.single('photo'),async(req,res,next)=>{try{
  const old=(await db('SELECT * FROM students WHERE id=$1',[req.params.id])).rows[0];if(!old)return res.status(404).json({error:'Student not found'});
  const b=req.body;const photo=req.file?`data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`:old.photo;const hash=b.password?bcrypt.hashSync(b.password,12):old.password_hash;
  await db(`UPDATE students SET user_id=$1,password_hash=$2,name=$3,guardian=$4,phone=$5,batch=$6,fees=$7,admission_date=$8,address=$9,photo=$10,active=$11 WHERE id=$12`,[b.user_id||old.user_id,hash,b.name||old.name,b.guardian||'',b.phone||'',b.batch||'',Number(b.fees||0),b.admission_date||'',b.address||'',photo,b.active!=='0',req.params.id]);res.json({ok:true});
}catch(e){res.status(400).json({error:e.code==='23505'?'Student User ID already exists':e.message})}});
app.delete('/api/admin/students/:id',adminOnly,async(req,res,next)=>{try{await db('DELETE FROM students WHERE id=$1',[req.params.id]);res.json({ok:true})}catch(e){next(e)}});

app.get('/api/admin/exams',adminOnly,async(req,res,next)=>{try{const exams=(await db('SELECT * FROM exams ORDER BY id DESC')).rows;for(const e of exams)e.questions=(await db('SELECT * FROM questions WHERE exam_id=$1 ORDER BY id',[e.id])).rows;res.json(exams)}catch(e){next(e)}});
app.post('/api/admin/exams',adminOnly,async(req,res,next)=>{const client=await pool.connect();try{const b=req.body;if(!b.title||!Array.isArray(b.questions)||!b.questions.length)return res.status(400).json({error:'Exam title and at least one question are required'});await client.query('BEGIN');const e=(await client.query('INSERT INTO exams(title,subject,duration,published) VALUES($1,$2,$3,$4) RETURNING id',[b.title,b.subject||'',Number(b.duration||30),!!b.published])).rows[0];for(const q of b.questions){await client.query('INSERT INTO questions(exam_id,question,option_a,option_b,option_c,option_d,correct) VALUES($1,$2,$3,$4,$5,$6,$7)',[e.id,q.question,q.option_a,q.option_b,q.option_c,q.option_d,q.correct]);}await client.query('COMMIT');res.json({ok:true,id:e.id});}catch(e){await client.query('ROLLBACK');next(e)}finally{client.release()}});
app.put('/api/admin/exams/:id',adminOnly,async(req,res,next)=>{const client=await pool.connect();try{const b=req.body;await client.query('BEGIN');await client.query('UPDATE exams SET title=$1,subject=$2,duration=$3,published=$4 WHERE id=$5',[b.title,b.subject||'',Number(b.duration||30),!!b.published,req.params.id]);await client.query('DELETE FROM questions WHERE exam_id=$1',[req.params.id]);for(const q of (b.questions||[]))await client.query('INSERT INTO questions(exam_id,question,option_a,option_b,option_c,option_d,correct) VALUES($1,$2,$3,$4,$5,$6,$7)',[req.params.id,q.question,q.option_a,q.option_b,q.option_c,q.option_d,q.correct]);await client.query('COMMIT');res.json({ok:true})}catch(e){await client.query('ROLLBACK');next(e)}finally{client.release()}});
app.delete('/api/admin/exams/:id',adminOnly,async(req,res,next)=>{try{await db('DELETE FROM exams WHERE id=$1',[req.params.id]);res.json({ok:true})}catch(e){next(e)}});
app.post('/api/admin/exams/:id/publish',adminOnly,async(req,res,next)=>{try{await db('UPDATE exams SET published=NOT published WHERE id=$1',[req.params.id]);res.json({ok:true})}catch(e){next(e)}});

app.get('/api/admin/results',adminOnly,async(req,res,next)=>{try{res.json((await db(`SELECT a.id,a.score,a.total,a.submitted_at,s.user_id,s.name,e.title,e.subject FROM attempts a JOIN students s ON s.id=a.student_id JOIN exams e ON e.id=a.exam_id ORDER BY a.submitted_at DESC`)).rows)}catch(e){next(e)}});
app.get('/api/admin/payments',adminOnly,async(req,res,next)=>{try{res.json((await db(`SELECT p.*,s.user_id,s.name FROM payments p JOIN students s ON s.id=p.student_id ORDER BY p.paid_on DESC,p.id DESC`)).rows)}catch(e){next(e)}});
app.post('/api/admin/payments',adminOnly,async(req,res,next)=>{try{const b=req.body;if(!b.student_id||!b.amount||!b.paid_on)return res.status(400).json({error:'Student, amount and date are required'});await db('INSERT INTO payments(student_id,amount,paid_on,note) VALUES($1,$2,$3,$4)',[b.student_id,Number(b.amount),b.paid_on,b.note||'']);res.json({ok:true})}catch(e){next(e)}});
app.delete('/api/admin/payments/:id',adminOnly,async(req,res,next)=>{try{await db('DELETE FROM payments WHERE id=$1',[req.params.id]);res.json({ok:true})}catch(e){next(e)}});
app.get('/api/admin/settings',adminOnly,async(req,res,next)=>{try{const r=await db('SELECT key,value FROM settings');res.json(Object.fromEntries(r.rows.map(x=>[x.key,x.value])))}catch(e){next(e)}});
app.put('/api/admin/settings',adminOnly,async(req,res,next)=>{try{for(const [k,v] of Object.entries(req.body||{}))await db('INSERT INTO settings(key,value) VALUES($1,$2) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value',[k,String(v)]);res.json({ok:true})}catch(e){next(e)}});

app.use(express.static(path.join(__dirname,'public')));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.use((err,req,res,next)=>{console.error(err);res.status(400).json({error:err.message||'Request failed'})});

initDb().then(()=>app.listen(PORT,'0.0.0.0',()=>console.log(`ManSri Coaching Center running on port ${PORT}`))).catch(err=>{console.error('Database initialization failed:',err);process.exit(1)});
